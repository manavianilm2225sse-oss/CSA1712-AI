
# Vacuum Cleaner Problem in AI

# Initial state of rooms
rooms = {
    'A': 'Dirty',
    'B': 'Dirty'
}

# Starting position of vacuum cleaner
position = 'A'

while 'Dirty' in rooms.values():
    print("Vacuum is in Room", position)

    if rooms[position] == 'Dirty':
        print("Room", position, "is Dirty. Cleaning...")
        rooms[position] = 'Clean'
    else:
        print("Room", position, "is already Clean.")

    # Move to the other room
    if position == 'A':
        position = 'B'
    else:
        position = 'A'

print("\nAll rooms are clean!")
print("Final State:", rooms)
