
from itertools import permutations

def tsp(graph, start):
    n = len(graph)
    cities = [i for i in range(n) if i != start]
    min_cost = float('inf')
    best_path = []

    for p in permutations(cities):
        path = [start] + list(p) + [start]
        cost = sum(graph[path[i]][path[i+1]]
                   for i in range(n))

        if cost < min_cost:
            min_cost = cost
            best_path = path

    print("Minimum cost:", min_cost)
    print("Best path:", best_path)

graph = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]

tsp(graph, 0)
